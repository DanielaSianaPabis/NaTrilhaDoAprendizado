var cont
cont=0

while(cont<10){
    alert("Como deixar o usuário louco com while, em: "+cont)
}
for(cont=0; cont<10; cont++){
    alert("Como deixar o usuário louco com for, em: "+cont)
}