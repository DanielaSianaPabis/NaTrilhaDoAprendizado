var n1, n2, divisao, multiplicacao, soma, subtracao

n1= prompt("Digite o primeiro valor: ")

n2= prompt("Digite o outro valor: ")

soma= parseInt(n1) + parseInt(n2)
alert("O resultado da soma entre estes números inteiros é: "+soma)

subtracao= parseInt(n1) - parseInt(n2)
alert("O resultado da subtração entre estes números inteiros é: "+subtracao)

multiplicacao= parseInt(n1) * parseInt(n2)
alert("O resultado da multiplicação entre estes números inteiros é: "+multiplicacao)

divisao= parseInt(n1) / parseInt(n2)
alert("O resultado da divisão entre estes números inteiros é: "+divisao)
