var a, b, c, m

a=8
b=4
c=a+b
m="O resultado da soma é "
alert(m+c)