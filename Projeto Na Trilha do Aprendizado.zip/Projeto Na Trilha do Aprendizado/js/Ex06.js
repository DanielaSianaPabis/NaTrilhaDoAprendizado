var n1, n2, divisao, multiplicacao, soma, subtracao

n1= prompt("Digite o primeiro valor: ")

n2= prompt("Digite o outro valor: ")

soma= parseFloat(n1) + parseFloat(n2)
alert("O resultado da soma entre estes números reais é: "+soma)

subtracao= parseFloat(n1) - parseFloat(n2)
alert("O resultado da subtração entre estes números reais é: "+subtracao)

multiplicacao= parseFloat(n1) * parseFloat(n2)
alert("O resultado da multiplicação entre estes números reais é: "+multiplicacao)

divisao= parseFloat(n1) / parseFloat(n2)
alert("O resultado da divisão entre estes números reais é: "+divisao)