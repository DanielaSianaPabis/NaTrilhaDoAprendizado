var valor
valor=prompt("Digite um valor para descobrir se este é múltiplo de 3 ou 7 (caso não apareça nada, o número digitado não é multiplo de 3 e/ou 7):")
if(valor%3==0){
    alert(valor+" é múltiplo de 3")
}
if(valor%7==0){
    alert(valor+" é múltiplo de 7")
}