alert("Mensagem de alerta no script externo")

prompt("Entrada de dados no arquivo externo")