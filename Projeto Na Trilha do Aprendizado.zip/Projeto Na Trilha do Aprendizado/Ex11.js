var n, cont, t

n=parseInt(prompt("Entre com o valor da tabuada: "))
/*
while(cont<11){
    t=n*cont
    document.write("<t2>  "+t+" </t2>)
    cont++
}
*/
for(cont=0; cont<11; cont++)
{
    t=n*cont
    document.write("<t1> "+t+ "</t2>")
}